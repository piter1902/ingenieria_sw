import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("3509c072-b67d-4e89-a964-3f94f5d4e8e7")
public class Avion {
    @objid ("9b85b93f-96ad-4685-bd42-1012db4ac6c2")
    public String modelo;

}
