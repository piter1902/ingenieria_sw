import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("10443c7b-5272-4c4d-ac1d-24e263e23aef")
public class Asiento {
    @objid ("39ca11a9-aa95-460e-9fde-a2bc3b481ce7")
    public int numAsiento;

}
