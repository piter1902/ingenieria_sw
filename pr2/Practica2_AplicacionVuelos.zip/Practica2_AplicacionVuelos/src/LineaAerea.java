import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("4e34083a-421d-42c2-a35c-9dd6d762e89b")
public class LineaAerea {
    @objid ("5031e42a-c56a-4164-95a0-6ca6fdf9f11a")
    public String nombre;

}
