import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("17385b31-a906-4091-8406-feb5ceb73adb")
public class Aeropuerto {
    @objid ("e5183581-d894-4fee-858f-57e5e3b108bd")
    public String nombre;

}
