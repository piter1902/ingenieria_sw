import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("1b2a9dcd-d6a4-414f-b5e0-b0a85a035a9b")
public class Pasajero {
    @objid ("c8eeeaba-6789-4506-9bf7-c60e073a734b")
    public String nombre;

}
