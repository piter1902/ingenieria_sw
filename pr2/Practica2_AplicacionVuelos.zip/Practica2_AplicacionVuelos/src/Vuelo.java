import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("3c201814-903d-46b3-a287-79a6fe2f55bd")
public class Vuelo {
    @objid ("4687e5ad-16f2-4a51-85bc-efba594cc279")
    public Date fecha;

}
