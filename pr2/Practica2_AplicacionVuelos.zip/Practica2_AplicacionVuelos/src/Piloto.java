import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("4498a501-db8f-4f0c-bd5e-1e99dfc8da85")
public class Piloto {
    @objid ("92b333c8-84ac-44fc-a9c3-ffc5e570b1de")
    public String nombre;

}
